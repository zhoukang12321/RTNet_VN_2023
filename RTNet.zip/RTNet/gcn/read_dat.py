import torch
mat=torch.load('adjmat.dat')
mat=mat.numpy()
for i in mat:
	
	
	i=str(i)
	print(i)
	
	with open ("test.txt", "a+") as f:
		f.write ('\n'+i)
print(f)
file = open("test.txt")
file2=open('test2.txt',"a+")
for line in file:
	for index in line:
		
		if line[index]!=']':
			line=line.strip('\n')
		else:pass
	file2.write("\n"+line)

file.close()
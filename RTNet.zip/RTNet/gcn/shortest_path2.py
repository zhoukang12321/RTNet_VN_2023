import pandas as pd
import copy

A = pd.read_csv (r'matrix.csv', index_col=0)
# A是邻接矩阵，相邻对象元素为1，不相邻为0

D = copy.deepcopy (A)
# 用于储存节点对的最短路径，相邻的为实际权值（本例为1），不相邻设置为很大的数（远大于所有边的权值，本例设置为999）
ilter = [i for i in range (len (A))]
# o代表起始节点ID,d是终点ID,mid是内插节点
for o in ilter:
	for d in ilter:
		if d == o:
			continue
		if D.iloc [o, d] == 0:
			D.iloc [o, d] = 999
print ("得到矩阵D")
# D初始化完毕


# 使用Floyd算法计算SP

for mid in ilter:
	if mid % 10 == 0:
		print ("进度~~%d/%d" % (mid, len (A)))
	for o in ilter:
		for d in ilter:
			if D.iloc [o, mid] != 999 and D.iloc [mid, d] != 999 and D.iloc [o, d] > D.iloc [o, mid] + D.iloc [mid, d]:
				D.iloc [o, d] = D.iloc [o, mid] + D.iloc [mid, d]

D.to_csv (r'ODM.csv')